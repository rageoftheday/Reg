# Cockatrice 3.1.2 picture-request status bounds

Base: Cockatrice 3.1.2 (`2026-10-25-Release-3.1.2`, commit `bbc7e46`).

## Problem
The picture-loader status popup can retain stalled requests indefinitely. A busy client can therefore accumulate a large status widget tree. In addition, the success slot increments the progress value before it verifies that a matching active request row still exists. Once rows are bounded/pruned, a late success can otherwise inflate the visible counter.

## Behavior in this patch
- At most **10 request rows** are retained in the popup; oldest rows are removed first.
- A **finished** row is retained for **10 seconds after completion**.
- An **unfinished/stalled** row is removed after **120 seconds**.
- Removing a finished row decrements both progress value and maximum.
- Removing an unfinished row decrements only the maximum.
- A success event only increments the visible progress value when a matching unfinished row still exists.
- If several unfinished rows share the same URL, one success signal completes **exactly one** row; duplicate requests are completed one signal at a time.
- A completion arriving after its row was pruned does not change the visible counter.

## Scope
Only the picture-loader status UI/accounting is changed. There are no token, card database, XML, network protocol, or user-data changes.

## Files changed
- `cockatrice/src/interface/card_picture_loader/card_picture_loader_request_status_display_widget.cpp`
- `cockatrice/src/interface/card_picture_loader/card_picture_loader_request_status_display_widget.h`
- `cockatrice/src/interface/card_picture_loader/card_picture_loader_status_bar.cpp`

## Apply
From the root of a Cockatrice 3.1.2 source checkout:

```bash
patch -p1 < Cockatrice-3.1.2-status-request-bounds.patch
```

## Suggested maintainer tests
1. Queue 1 request and complete it: row remains briefly, then disappears 10 seconds after completion and counter returns to `0/0`.
2. Queue a request that never completes: row disappears at 120 seconds and counter maximum decreases without increasing value.
3. Queue more than 10 requests: only the newest 10 rows remain.
4. Complete a request after its row has already been removed by the cap or timeout: counter must not increase.
5. Queue the same URL twice, then emit one success: exactly one row should finish and progress should increase by one. Emit a second success: the second row should finish.
6. Emit another success after both duplicate rows are finished: progress must not increase again.
7. Mix completed and unfinished rows while pruning: `0 <= value <= maximum` must always hold.

`tests/status_logic_model.py` is a small behavior model for these accounting cases; it does not replace Cockatrice's C++ test suite.
