from dataclasses import dataclass

MAX_ROWS = 10
FINISHED_TTL = 10
STALE_TTL = 120

@dataclass
class Row:
    url: str
    started: int
    finished_at: int | None = None

class Model:
    def __init__(self):
        self.rows=[]
        self.value=0
        self.maximum=0

    def _remove(self, row):
        if row.finished_at is not None:
            self.value=max(0,self.value-1)
        self.maximum=max(0,self.maximum-1)
        self.rows.remove(row)
        assert 0 <= self.value <= self.maximum

    def queue(self,url,now):
        self.rows.append(Row(url,now))
        self.maximum += 1
        self.rows.sort(key=lambda r:r.started)
        while len(self.rows)>MAX_ROWS:
            self._remove(self.rows[0])

    def success(self,url,now):
        matched=False
        for r in self.rows:
            if r.url==url and r.finished_at is None:
                r.finished_at=now
                matched=True
                break
        if matched:
            self.value=min(self.value+1,self.maximum)
        assert 0 <= self.value <= self.maximum

    def clean(self,now):
        for r in list(self.rows):
            expired_finished=r.finished_at is not None and now-r.finished_at >= FINISHED_TTL
            expired_stalled=r.finished_at is None and now-r.started >= STALE_TTL
            if expired_finished or expired_stalled:
                self._remove(r)

m=Model(); m.queue('a',0); m.success('a',5); m.clean(14); assert (len(m.rows),m.value,m.maximum)==(1,1,1); m.clean(15); assert (len(m.rows),m.value,m.maximum)==(0,0,0)
m=Model(); m.queue('a',0); m.clean(119); assert len(m.rows)==1; m.clean(120); assert (len(m.rows),m.value,m.maximum)==(0,0,0)
m=Model(); [m.queue(str(i),i) for i in range(12)]; assert len(m.rows)==10 and [r.url for r in m.rows]==[str(i) for i in range(2,12)] and m.maximum==10
m.success('0',20); assert (m.value,m.maximum)==(0,10) # pruned completion
m.success('2',20); assert (m.value,m.maximum)==(1,10); m.success('2',21); assert (m.value,m.maximum)==(1,10)
m=Model(); m.queue('dup',0); m.queue('dup',1); m.success('dup',2); assert sum(r.finished_at is not None for r in m.rows)==1 and m.value==1 and m.maximum==2
m.success('dup',3); assert sum(r.finished_at is not None for r in m.rows)==2 and m.value==2 and m.maximum==2
m.success('dup',4); assert sum(r.finished_at is not None for r in m.rows)==2 and m.value==2 and m.maximum==2
print('PASS: 10-row cap, 10s finished TTL, 120s stalled TTL, and late/duplicate completion accounting')
